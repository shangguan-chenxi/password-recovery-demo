<?php
header('Location: ./html');