<?php

define("USER_DB", "../login_db/");
define("RESET_DB", "../reset_db/");
define("MAX_ATTEMPTS", 5);

class user{
    public $password;
    public $secret;
}

$SECRET = "ab91f5d2008953509c5c4574125139d36c4e7cbad83ec3f7b995db6d5531168c502304194e1d68753255c7111467f352f4c34bbf9b6445027605ca72833b2861";
$LIFE_SPAN = 60 * 15;

/*
function issue_token($usr){
    global $LIFE_SPAN;
    $token_header = json_encode(array("alg"=>"HS256", "typ"=>"JWT"));
    $token_body = json_encode(array("user"=>$usr,"iat"=>time(), "exp"=>time() + $LIFE_SPAN));
    $str = str_replace('=','',base64_encode($token_header)) . '.' . str_replace('=','',base64_encode($token_body));
    $signature = str_replace('=','',crypto($str));
    return $str . '.' . $signature;
}

function validate_token($token){
    $Arr = explode(".", $token);
    $str = $Arr[0] . '.' . $Arr[1];
    $signature = crypto($str);
    return (base64_decode($signature) == base64_decode($Arr[2]));
}
*/

function crypto($str){
    global $SECRET;
    return base64_encode(base_convert(hash("sha256", $str.$SECRET),16,10));
}

function do_submit_reset_check($username = '', $secret = ''){
    if(!ctype_alnum($username)){
        echo '用户名/SECRET不匹配';
        return;
    }
    
    if(!file_exists(USER_DB . $username . ".txt")){
        echo '用户名/SECRET不匹配';
        return;
    }
    
    $data = unserialize(file_get_contents(USER_DB . $username . ".txt"));
    
    // 检验通过
    if(strcmp($data->secret, $secret) == 0){
        
        // 生成令牌
        global $LIFE_SPAN;
        $token_header = json_encode(array("alg"=>"HS256", "typ"=>"JWT"));
        $token_body = json_encode(array("user"=>$username,"iat"=>time(), "exp"=>time() + $LIFE_SPAN));
        
        // 保存到文件中的密匙
        $str = str_replace('=','',base64_encode($token_header)) . '.' . str_replace('=','',base64_encode($token_body));
        
        // 用户能拿到的密匙
        $key = crypto($str);
        
        // 写入到文件
        $F = fopen(RESET_DB . $username . ".txt", "w");
        fwrite($F, $str);
        fclose($F);
        
        // 提示链接可以用于重置密码
        echo '请转到<a href="./reset-password.php?user='.$username.'&token='.$key.'"> 这里 </a> 重置您的密码, 链接15分钟内有效, 并在密码被重置后即时失效';
        return;
    }
    
    // 请求失败
    echo '用户名/SECRET不匹配';
    
}

function do_login_check($username, $password){
    if(!ctype_alnum($username)){
        echo '用户名/密码不匹配';
        return;
    }
    
    if(!file_exists(USER_DB . $username . ".txt")){
        echo '用户名/密码不匹配';
        return;
    }
    
    // 文件位置
    $credentials = unserialize(file_get_contents(USER_DB . $username . ".txt"));
    if(strcmp($credentials->password, $password) == 0){
        // 提示登陆成功
        echo '用户：' . $username . ', 您已登录';
        return;
    }
    
    // 提示登陆失败
    echo '用户名/密码不匹配';
    
}

function do_reset($username, $token, $newPwd){
    if(!ctype_alnum($username)){
        return;
    }
    
    if(!file_exists(RESET_DB . $username . ".txt")){
        echo '请求已失效';
        return;
    }
    
    
    $reset_db = file_get_contents(RESET_DB . $username . ".txt");
    $arr = explode(".", $reset_db);
    $timeline = json_decode(base64_decode($arr[1]));
    
    /*
    echo '$reset_db: ' . $reset_db . '</br>';
    echo 'crypto($reset_db): ' . crypto($reset_db) . '</br>';
    echo '$token: ' . $token . '</br>';
    echo 'time(): ' . time() . '</br>';
    echo '$timeline->exp: ' . $timeline->exp . '</br>';
    exit();
    */
    
    // 判断是否已经超时
    if(time() > $timeline->exp){
        echo '请求已失效';
        // 删除文件
        unlink(RESET_DB . $username . ".txt");
        return;
    }
    
    // 令牌校验正确
    if(strcmp(str_replace("=", '', crypto($reset_db)), str_replace("=", '', $token)) == 0){
        $user_db = unserialize(file_get_contents(USER_DB . $username . ".txt"));
        $user_db->password = $newPwd;
        $F = fopen(USER_DB . $username . ".txt", "w");
        fwrite($F, serialize($user_db));
        fclose($F);
        
        // 删除文件
        unlink(RESET_DB . $username . ".txt");
        
        // 提示重置密码成功
        echo '密码重置成功, <a href="./login.php">登录</a>';
        return;
    }
    
    // 提示发生错误
    echo '发生错误';
    
}